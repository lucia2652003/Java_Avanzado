package com.pruebajpa.ejerciciolineaproduccion.logica;

public class Estacion {
    
     //private String nombre;

     public void ensamblar(String nombre) {
         System.out.println("Estoy ensamblando " + nombre);
     }
     
       public void controlar(String nombre) {
         System.out.println("Estoy controlando calidad " + nombre);
     }
    
     public void embalar(String nombre) {
         System.out.println("Estoy embalando " + nombre);
     }
    
}
