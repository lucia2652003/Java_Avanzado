package com.pruebajpa.ejerciciolineaproduccion;
import com.pruebajpa.ejerciciolineaproduccion.logica.Estacion;
import com.pruebajpa.ejerciciolineaproduccion.logica.Trabajador;

public class EjercicioLineaProduccion {

    public static void main(String[] args) {
       
           
        Estacion estac = new Estacion();
       
        //creamos varios hilos (personas)
        int personas = 3;

        //Trabajador es la clase que implementa la interfaz Runnable para simular las 
        //operaciones de un usuario. 
    
        for (int i = 1; i <= personas; i++) {
            Thread persona = new Thread(new Trabajador(estac, "Trabajador " + i));
            persona.start();
        }
        
        
        
    }
}
