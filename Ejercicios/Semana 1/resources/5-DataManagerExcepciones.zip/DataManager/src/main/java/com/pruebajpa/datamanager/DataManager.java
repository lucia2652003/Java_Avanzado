package com.pruebajpa.datamanager;

import com.pruebajpa.datamanager.logica.Manager;

public class DataManager {

    public static void main(String[] args) {
        Manager manager = new Manager();

        manager.addData(10);
        manager.addData(20);
        manager.addData(30);

        //captamos la excepción propia de Java ArrayIndexOutOfBoundsException
        try {
            System.out.println(manager.getData(-1));
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }

        try {
            System.out.println(manager.getData(11));
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getMessage());
        }
    }
}
