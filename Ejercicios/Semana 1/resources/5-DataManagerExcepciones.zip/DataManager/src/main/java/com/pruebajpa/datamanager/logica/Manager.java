
package com.pruebajpa.datamanager.logica;


public class Manager {
    private static final int VECTOR_SIZE = 10;

    private int[] vector;

    public Manager() {
        this.vector = new int[VECTOR_SIZE];
    }

    public void addData(int data) {
        this.vector[this.vector.length - 1] = data;
    }

    public int getData(int index) throws ArrayIndexOutOfBoundsException {
        if (index < 0 || index >= this.vector.length) {
            throw new ArrayIndexOutOfBoundsException("El índice especificado está fuera del rango del vector.");
        }

        return this.vector[index];
}
    
}
