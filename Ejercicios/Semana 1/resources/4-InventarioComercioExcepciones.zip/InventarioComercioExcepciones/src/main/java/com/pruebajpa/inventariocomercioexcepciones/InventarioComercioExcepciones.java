package com.pruebajpa.inventariocomercioexcepciones;

import com.pruebajpa.inventariocomercioexcepciones.exceptions.DatosInvalidosException;
import com.pruebajpa.inventariocomercioexcepciones.logica.AdminInventario;

public class InventarioComercioExcepciones {

    public static void main(String[] args) {
        AdminInventario manager = new AdminInventario();

        //Se intenta agregar un producto con datos válidos.
        try {
            manager.addProduct("Producto 1", 10.0, 100);
        } catch (DatosInvalidosException e) {
            System.out.println(e.getMessage());
        }
        
        //Se intenta agregar un producto con un nombre vacío.
        try {
            manager.addProduct("", 10.0, 100);
        } catch (DatosInvalidosException e) {
            System.out.println(e.getMessage());
        }
        //Se intenta agregar un producto con un precio negativo.
        try {
            manager.addProduct("Producto 2", -10.0, 100);
        } catch (DatosInvalidosException e) {
            System.out.println(e.getMessage());
        }
       //Se intenta agregar un producto con una cantidad disponible negativa. 
        try {
            manager.addProduct("Producto 3", 10.0, -100);
        } catch (DatosInvalidosException e) {
            System.out.println(e.getMessage());
        }
        
        /*En cada caso (salvo el primero), se espera que se lance una excepción DatosInvalidosException
        con el mensaje correspondiente.*/
    }
}
