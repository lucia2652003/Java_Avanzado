package com.pruebajpa.inventariocomercioexcepciones.logica;

import com.pruebajpa.inventariocomercioexcepciones.exceptions.DatosInvalidosException;

public class AdminInventario {
    
    //seteamos los mensajes predeterminados
    private static final String NOMBRE_PRODUCTO_VACIO = "El nombre del producto no puede estar vacío.";
    private static final String PRECIO_PRODUCTO_INVALIDO = "El precio del producto debe ser un número mayor que 0.";
    private static final String CANTIDAD_PRODUCTO_INVALIDA = "La cantidad disponible del producto no puede ser menor que 0.";

    public void addProduct(String name, double price, int quantity) throws DatosInvalidosException {
        // Validar el nombre del producto
        if (name.isEmpty()) {
            throw new DatosInvalidosException(NOMBRE_PRODUCTO_VACIO);
        }

        // Validar el precio del producto
        if (price <= 0) {
            throw new DatosInvalidosException(PRECIO_PRODUCTO_INVALIDO);
        }

        // Validar la cantidad disponible del producto
        if (quantity < 0) {
            throw new DatosInvalidosException(CANTIDAD_PRODUCTO_INVALIDA);
        }

        // Agregar el producto al inventario
        System.out.println("Producto Agregado Correctamente");
        // ...
    }
    
}
