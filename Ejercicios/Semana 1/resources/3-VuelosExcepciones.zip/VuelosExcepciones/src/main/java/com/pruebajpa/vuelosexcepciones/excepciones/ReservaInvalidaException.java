
package com.pruebajpa.vuelosexcepciones.excepciones;

public class ReservaInvalidaException extends Exception {
    public ReservaInvalidaException(String mensaje) {
        super(mensaje);
    }
}