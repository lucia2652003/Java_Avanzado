package com.pruebajpa.gestoreventos;

import com.pruebajpa.gestoreventos.logica.Evento;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class GestorEventos {

    public static void main(String[] args) {
       
     List<Evento> eventos = Arrays.asList(
                new Evento("Reunión equipo", LocalDate.of(2023, 11, 20), "Reunión"),
                new Evento("Conferencia tech", LocalDate.of(2023, 11, 22), "Conferencia"),
                new Evento("Taller de programación", LocalDate.of(2023, 11, 25), "Taller"),
                new Evento("Entrenamiento ventas", LocalDate.of(2023, 11, 21), "Entrenamiento"),
                new Evento("Charla motivacional", LocalDate.of(2023, 11, 23), "Conferencia")
        );

        // Filtrar eventos para una fecha específica
        LocalDate fechaEspecifica = LocalDate.of(2023, 11, 22);
        List<Evento> eventosFechaEspecifica = eventos.stream()
                .filter(evento -> evento.getFecha().equals(fechaEspecifica))
                .collect(Collectors.toList());
        System.out.println("Eventos para el " + fechaEspecifica + ": " + eventosFechaEspecifica);

        // Agrupar por categoría y contar eventos por categoría
        Map<String, Long> eventosPorCategoria = eventos.stream()
                .collect(Collectors.groupingBy(Evento::getCategoria, Collectors.counting()));
        System.out.println("Cantidad de eventos por categoría: " + eventosPorCategoria);

        // Encontrar evento más próximo en el tiempo
        LocalDate fechaActual = LocalDate.now();
        Optional<Evento> eventoProximo = eventos.stream()
                .filter(evento -> evento.getFecha().isAfter(fechaActual))
                .min(Comparator.comparing(Evento::getFecha));
        eventoProximo.ifPresent(evento ->
                System.out.println("El próximo evento es: " + evento));   
        
    }
}
