package com.pruebajpa.resolucionempleados;

import com.pruebajpa.resolucionempleados.logica.Empleado;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class ResolucionEmpleados {

    public static void main(String[] args) {
        
        List<Empleado> empleados = Arrays.asList(
                new Empleado("Juan", 3000, "Desarrollador"),
                new Empleado("María", 3500, "Analista"),
                new Empleado("Pedro", 4000, "Gerente"),
                new Empleado("Sofía", 3200, "Desarrollador"),
                new Empleado("Luis", 3800, "Analista")
        );

        // Filtrar empleados con salario mayor a cierto valor
        double valorEspecifico = 3500;
        List<Empleado> salarioMayor = empleados.stream()
                .filter(empleado -> empleado.getSalario() > valorEspecifico)
                .collect(Collectors.toList());
        System.out.println("Empleados con salario mayor a " + valorEspecifico + ": " + salarioMayor);

        // Agrupar por categoría y calcular salario promedio
        Map<String, Double> salarioPromedioPorCategoria = empleados.stream()
                .collect(Collectors.groupingBy(Empleado::getCategoria,
                        Collectors.averagingDouble(Empleado::getSalario)));
        System.out.println("Salario promedio por categoría: " + salarioPromedioPorCategoria);

        // Encontrar empleado con el salario más alto
        Optional<Empleado> empleadoSalarioMaximo = empleados.stream()
                .max(Comparator.comparingDouble(Empleado::getSalario));
        empleadoSalarioMaximo.ifPresent(empleado ->
                System.out.println("Empleado con el salario más alto: " + empleado));
        
    }
}
